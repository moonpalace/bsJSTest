<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?
include('Crypt/RSA.php');

$rsa = new Crypt_RSA();
 
//$rsa->setPrivateKeyFormat(CRYPT_RSA_PRIVATE_FORMAT_PKCS1);
$rsa->setPublicKeyFormat(CRYPT_RSA_PUBLIC_FORMAT_RAW);

//define('CRYPT_RSA_EXPONENT', 65537);
//define('CRYPT_RSA_SMALLEST_PRIME', 64); // makes it so multi-prime RSA is used
extract($rsa->createKey(2048)); // == $rsa->createKey(1024) where 1024 is the key size

$_SESSION['private'] = $privatekey;

//echo $privatekey;

$e = $publickey["e"]->toHex();
$n = $publickey["n"]->toHex();

?>



    <script type="text/javascript" src="http://projectbs.github.io/bsJS/bsjs.0.6.js"></script>

    <script type="text/javascript">
        bs.plugin('rsa', null);
        bs(function () {

        });
        function Encryt() {
        
            var modulus = document.getElementById("Modulus").value;
            var exponent = document.getElementById("Exponent").value;
            var source = document.getElementById("source").value;

            var encrytedString = bs.rsa(modulus, exponent, source, true);

            document.getElementById("EncrytData").value = encrytedString;
        }
    </script>

</head>
<body>
서버에서 넘겨준 공개키 정보<br>
Modulus : <input type="text" id="Modulus" value="<? echo $n ?>" /><br>
Exponent : <input type="text" id="Exponent" value='<? echo $e ?>' /><br>
<br><br>
Source : <input type="text" id="source" name="source" /><input type="button" onclick="Encryt();" value="Encryt" /><br />
<form action="base64testresult.php" method="post">
Encrypted : <input type="text" id="EncrytData" name="EncrytData" readonly="readonly" /><input type="submit" value="Decryt" /><br />
</form>
</body>
</html>
