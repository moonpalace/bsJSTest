<?php
session_start();
include('Crypt/RSA.php');

    
    function decrypt($privatekey, $encrypted) {
		$rsa = new Crypt_RSA();

		$encrypted=pack('H*', $encrypted);

		$rsa->loadKey($privatekey);
		$rsa->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);
		return $rsa->decrypt($encrypted);		
	}


$privatekey = $_SESSION['private'];
$cipherbase64 = $_POST['EncrytData'];
$cipherbinary = base64_decode($cipherbase64);
$cipherhex = bin2hex($cipherbinary);


//echo 'hello';
//echo $text;
echo decrypt($privatekey, $cipherhex);
//echo 'bye';


?>